import 'package:flutter/material.dart';

const primaryColor = Color(0xffF0BDBD);
const myBackgroundColor = Color.fromARGB(255, 245, 245, 245);
const ksecondryColor = Color(0xff101010);
